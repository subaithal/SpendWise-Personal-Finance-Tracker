# SpendWise - complete project

- `web/index.html`   : the full web app (single file). Deploy as-is.
- `android-app/`     : Android (Capacitor) project. See android-app/README.md. `android-app/www/index.html` is the same app as web/index.html.

## Deploy the web version (free, ~1 minute)
- Netlify: open https://app.netlify.com/drop and drag the `web` folder in. You get a public link.
- GitHub Pages: create a repo, upload `web/index.html` as `index.html`, then Settings > Pages > deploy from main branch.
- Vercel: `npx vercel` inside the `web` folder.

## Build the Android app
Follow android-app/README.md (npm install, npx cap add android, npm run patch, npx cap sync android, npx cap open android).

## Keep in sync
If you edit web/index.html, copy it over android-app/www/index.html and run `npx cap sync android`.

## Your data
Data is stored in each browser/app's localStorage. Use Profile (gear) > Data > Copy backup / Restore backup to move it.
