# SpendWise Android

The existing SpendWise web app (`www/index.html`) wrapped as a native Android app with **Capacitor**.
No features were removed. The same UI, same localStorage data model, same purple theme. A notification layer was added that activates only inside the Android app.

## What you need (one time)
- Node.js (current LTS) - https://nodejs.org
- Android Studio (includes the Android SDK + JDK) - https://developer.android.com/studio
- An Android phone + USB cable (or an emulator)
- Check https://capacitorjs.com/docs/getting-started/environment-setup for the current version requirements.

## Build and run
```bash
cd spendwise-android
npm install
npx cap add android          # creates the android/ project
npm run patch                # adds notification permissions + notification icon
npx cap sync android         # copies www/ into the Android project
npx cap open android         # opens Android Studio
```
In Android Studio: wait for Gradle sync, plug in your phone, press the green **Run** button.

**Phone setup:** Settings > About phone > tap *Build number* 7 times > Developer options > enable *USB debugging* > plug in > tap *Allow* on the phone.

**Share as an APK:** Build > Build Bundle(s)/APK(s) > Build APK(s), then copy `app-debug.apk` to the phone and install it (allow "install unknown apps").

**After editing www/index.html:** run `npx cap sync android`, then Run again.

## Move your existing data
The Android app has its own storage, so it starts empty. In the old web version: Profile (gear) > Data > **Copy backup**. In the Android app: Profile > Data > paste into the box > **Restore backup**.

## How notifications work
| Notification | When | Works when app is closed |
|---|---|---|
| Daily budget 80% / exceeded | Instantly when an expense is saved | n/a (spending is only added inside the app) |
| Monthly budget 80% | Instantly when an expense is saved | n/a |
| Savings reminder | Daily 9:00 AM (repeating) | Yes |
| Recurring expense due | 9:00 AM on the due day (next 6 months) | Yes |
| Night summary | 9:00 PM daily (next 14 days) | Yes |
| Weekly report | Sunday 8:00 PM (next 8 weeks) | Yes |
| Monthly report | Last day of month 8:00 PM (next 6 months) | Yes |

Scheduled texts are computed from your stored data and rebuilt after every change, then handed to Android's alarm system. Open the app at least every ~2 weeks so the schedule window refreshes.

## Test checklist (on the phone)
1. Open the app > sign up > Save salary setup. **Allow** the notification permission dialog.
2. Profile/Home > bell > **Send test**: a notification appears now.
3. Bell > **Test in 1 min**: press Home, swipe the app away from Recents, wait: it should arrive with the app closed.
4. Home > Budgets > set Daily budget 100 > Add expense 85: the 80% warning. Add 30 more: the exceeded alert.
5. Recurring: add one with today's day: it appears at 9 AM (or a tap on "Due today" in the app).
6. Optional check of pending alarms: `adb shell dumpsys alarm | grep com.spendwise.app`

## If notifications don't show
- Android 13+: Settings > Apps > SpendWise > Notifications must be on.
- Android 12+: Bell screen may show **Allow exact reminder timing**. Tap it and allow, or reminders can arrive a few minutes late.
- Xiaomi/Oppo/Vivo/Samsung: set Battery > SpendWise > *Unrestricted* and allow Autostart.
- Force-stopping the app from Settings cancels Android alarms until you open it again.

## Future SMS/UPI tracking (prepared, not active)
- `www/index.html` already has the pending queue and confirm flow, the parser (OTP messages rejected, raw SMS never stored) and `window.spendwiseIngestSms(text)` for a native listener to call.
- `android-extras/sms/` contains a disabled `SmsReceiver.kt` and a manifest snippet. Nothing is registered, so the current app is unaffected.
- Google Play heavily restricts SMS permissions. For personal use it is fine.
