package com.spendwise.app
// FUTURE USE - not registered in the manifest, so it does nothing until you enable it (see README, "Future SMS/UPI tracking").
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val body = Telephony.Sms.Intents.getMessagesFromIntent(intent).joinToString("") { it.messageBody ?: "" }
        if (Regex("(?i)otp|password|cvv|\\bpin\\b").containsMatchIn(body)) return          // never touch security messages
        if (!Regex("(?i)debit|spent|paid|sent").containsMatchIn(body)) return              // only debit-looking messages
        // TODO: pass `body` to the WebView through a small Capacitor plugin, which calls
        //       window.spendwiseIngestSms(body)  (already implemented in www/index.html).
        // That function parses amount/merchant/time/payment method and stores ONLY those fields as a pending
        // suggestion. The user taps "Add Expense" to confirm. Never persist the raw SMS text.
    }
}
