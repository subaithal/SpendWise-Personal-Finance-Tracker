// Run AFTER `npx cap add android`. Adds notification permissions + the notification icon. Safe to run repeatedly.
const fs = require('fs'), path = require('path');
const main = path.join(__dirname, '..', 'android', 'app', 'src', 'main');
const mf = path.join(main, 'AndroidManifest.xml');
if (!fs.existsSync(mf)) { console.error('android/ not found. Run "npx cap add android" first.'); process.exit(1); }
let x = fs.readFileSync(mf, 'utf8');
['POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED', 'VIBRATE'].forEach(p => {
  const name = 'android.permission.' + p;
  if (!x.includes(name)) x = x.replace('<application', `<uses-permission android:name="${name}" />\n    <application`);
});
fs.writeFileSync(mf, x);
const dir = path.join(main, 'res', 'drawable'); fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'ic_stat_icon.xml'),
`<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="#FFFFFFFF" android:pathData="M12,21.35l-1.45,-1.32C5.4,15.36 2,12.28 2,8.5 2,5.42 4.42,3 7.5,3c1.74,0 3.41,0.81 4.5,2.09C13.09,3.81 14.76,3 16.5,3 19.58,3 22,5.42 22,8.5c0,3.78 -3.4,6.86 -8.55,11.54L12,21.35z"/></vector>\n`);
console.log('Patched AndroidManifest.xml and added ic_stat_icon.xml');
